//: Playground - noun: a place where people can play


//Este programa está hecho con la versión 3 de Swift
//Version 8.0 beta 6 (8S201h)

//Me pareció más interesante imprimir todas las condiciones de un número
//En caso de que solo se quiera imprimir la última condición, sería:
//Reemplazar la instrucción: textoImpresion += Texto de la condición, por
//textoImpresion = Texto de la condición
//Es decir, quitar que la variable textoImpresion acumule los textos correspondientes y solo imprima el último


import UIKit

//0 - Generar los numero del 0 al 100
var numeros = 0...100
var textoImpresion = ""

//0 - Ciclo para la impresión de los números del 0 al 100
for numero in numeros {
    
    //1 - Si el número es divisible entre cinco, imprimir el número y la palabra Bingo
    if (numero % 5) == 0 {
        textoImpresion += " Bingo!!!"
    }
    
    //2 - Si el número es par, imprimir el número, más la palabra Par
    if (numero % 2) == 0 {
        textoImpresion += " Par!!!"
    } else {
        //3 - Si el número es impar, imprimir el número, más la palabra Par
        textoImpresion += " Impar!!!"
    }
    
    //4 - Si el número se encuentra entre un rango de 30 a 40, imprimir el número, más las palabras Viva Swift
    if numero >= 30 && numero <= 40 {
        textoImpresion += " Viva Swift!!!"
    }
    
    print("Número: \(numero)\(textoImpresion)")
    
    textoImpresion = ""
}
